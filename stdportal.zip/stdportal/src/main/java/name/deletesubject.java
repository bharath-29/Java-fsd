package name;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.cj.xdevapi.Statement;

/**
 * Servlet implementation class deletesubject
 */
@WebServlet("/deletesubject")
public class deletesubject extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    
    public void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException
    {

    	response.setContentType("text/html");
		PrintWriter ps = response.getWriter();
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection =DriverManager.getConnection("jdbc:mysql://localhost:3306/delsub","root","Bharath@29");
			if(request.getParameter("delete")!=null) {
				int id = Integer.parseInt(request.getParameter("delete"));
				PreparedStatement abc = null;
abc = connection.prepareStatement("delete form subdel where id=?");
abc.setInt(1, id);
abc.executeUpdate();
connection.close();
			}
		}catch(Exception m) {
			m.printStackTrace();
		}
    	
    	
    }
}
