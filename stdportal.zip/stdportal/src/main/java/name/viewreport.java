package name;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/report")
public class viewreport extends HttpServlet {
private static final long serialVersionUID = 1L;
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
response.setContentType("text/html");
PrintWriter ps = response.getWriter();
String name1 = request.getParameter("id");
ps.print("<table><tr><th>Id</th>");
ps.print("<th>studentame</th>");
ps.print("<th>classcode</th></tr>");
ps.print("<th>subject</th></tr>");
ps.print("<th>Teachername</th></tr>");
try {
Class.forName("com.mysql.jdbc.Driver");
Connection connection =
DriverManager.getConnection("jdbc:mysql://localhost:3306/addsubject","root","Bharath@29");
Statement statement = connection.createStatement();
 ResultSet re = statement.executeQuery("Select * from viewdata where id =  " );
 while(re.next()){
 
 ps.print("<tr>");
 ps.print("<td>");
 ps.print(re.getString(1));
 ps.print("</td>");
 
 ps.print("<td>");
 ps.print(re.getString(2));
 ps.print("</td>");
 
 ps.print("<td>");
 ps.print(re.getString(3));
 ps.print("</td>");
 
 ps.print("<td>");
 ps.print(re.getString(4));
 ps.print("</td>");
 ps.print("</tr>");
 
 
 ps.print("<td>");
 ps.print(re.getString(5));
 ps.print("</td>");
 ps.print("</tr>");
 
 }
 }catch(Exception m1) {
m1.printStackTrace();
}
ps.print("</table>");
}
protected void doPost(HttpServletRequest request,
HttpServletResponse response) throws ServletException, IOException {
doGet(request, response);}}