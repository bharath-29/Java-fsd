package name;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import name.studentDatabaseConnection;

@WebServlet("/class")
public class manageclass extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request,
HttpServletResponse response)
		throws ServletException, IOException
	{
		try {
			Connection con = DatabaseConnection.initializeDatabase();
			PreparedStatement st = con
				.prepareStatement("insert into manageclass values(?, ?,?,?)");
			st.setString(2, request.getParameter("subjectname"));
			st.setInt(3, Integer.valueOf(request.getParameter("classcode")));
			st.setString(4, request.getParameter("studentname"));
			st.setString(5, request.getParameter("teachername"));
			
			st.executeUpdate();
			st.close();
			con.close();
			PrintWriter out = response.getWriter();
			out.println("<html><body><b>Successfully Inserted"
						+ "</b></body></html>");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
