package automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AutomationTesting {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\admin\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.facebook.com/r.php");
		driver.manage().window().maximize();
	
		System.out.println("Title: " +driver.getTitle());
		System.out.println("Account Owner name : Bharath Ravindran"  );
		System.out.println("---------------------------------------");

		WebElement firstname = driver.findElement(By.name("firstname"));
		firstname.sendKeys("Bharath");
		System.out.println(firstname.getAttribute("value"));

		WebElement lastname = driver.findElement(By.name("lastname"));
		lastname.sendKeys("Ravindran");
		System.out.println(lastname.getAttribute("value"));

		WebElement contact = driver.findElement(By.name("reg_email__"));
		contact.sendKeys("8754251693");
		System.out.println(contact.getAttribute("value"));

		WebElement password = driver.findElement(By.id("password_step_input"));
		password.sendKeys("Bharath@29");
		System.out.println(password.getAttribute("value"));

		WebElement day = driver.findElement(By.id("day"));
		day.sendKeys("29");
		System.out.println(day.getAttribute("value"));

		WebElement month = driver.findElement(By.id("month"));
		month.sendKeys("August");
		System.out.println(month.getAttribute("value"));

		WebElement year = driver.findElement(By.id("year"));
		year.sendKeys("2001");
		System.out.println(year.getAttribute("value"));

		WebElement gender = driver.findElement(By.className("_58mt"));
		gender.click();
		System.out.println(gender.getAttribute("value"));
		WebElement signUp = driver.findElement(By.name("websubmit"));
		signUp.click();
		System.out.println(signUp.getAttribute("value"));
		System.out.println("---------------------------------");
		System.out.println("Account created successfully !!");
		System.out.println("Selenium Test run successfully");
		System.out.println("---------------------------------");

	}

}


