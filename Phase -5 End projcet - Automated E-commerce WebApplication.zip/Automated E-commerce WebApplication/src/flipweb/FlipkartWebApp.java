package flipweb;

import java.util.concurrent.TimeUnit;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.beust.jcommander.Parameters;


public class FlipkartWebApp {
	WebDriver driver;
	@SuppressWarnings("deprecation")
	@Deprecated
	@Test
	public void sample() {
		System.out.println("Welcome to automate E-Commerce Webapplication");
		System.out.println("*************************************");
		System.out.println("Application Testing Process Start....");
		System.out.println("***************************************");
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get("https://www.flipkart.com/");
		driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[1]/input")).sendKeys("plantbharath@gmail.com");
		driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[2]/input")).sendKeys("Bharath@29");
		driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div/div[2]/div/form/div[4]/button")).click();
		System.out.println("Login Successfully");
		System.out.println("********************");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}
	
	@BeforeMethod
	public void beforeMethod() {
				
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver= new ChromeDriver();
	
	}
		
	@AfterMethod
	public void afterMethod() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.get("https://www.flipkart.com/mobile-phones-store?fm=neo%2Fmerchandising&iid=M_0a4fb88d-291b-42b8-9355-0d6f213b309e_1_372UD5BXDFYS_MC.ZRQ4DKH28K8J&otracker=hp_rich_navigation_3_1.navigationCard.RICH_NAVIGATION_Mobiles_ZRQ4DKH28K8J&otracker1=hp_rich_navigation_PINNED_neo%2Fmerchandising_NA_NAV_EXPANDABLE_navigationCard_cc_3_L0_view-all&cid=ZRQ4DKH28K8J");
		System.out.println("Enter Mobile category successfully");
		System.out.println("***********************************");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.findElement(By.name("q")).sendKeys("iphone 13" + Keys.ENTER);
		System.out.println("Product found");
		System.out.println("**************");
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	driver.get("https://www.flipkart.com/apple-iphone-13-green-512-gb/p/itmdd397c451bdae?pid=MOBGC9VGEZQUXGW5&lid=LSTMOBGC9VGEZQUXGW5RRBL4C&marketplace=FLIPKART&q=iphone+13&store=tyy%2F4io&srno=s_1_12&otracker=search&otracker1=search&fm=organic&iid=5adb1188-bc62-40e1-be34-8b9add677d61.MOBGC9VGEZQUXGW5.SEARCH&ppt=clp&ppn=mobile-phones-store&ssid=ysn28zfbcw0000001665398511914&qH=c68a3b83214bb235");
	JavascriptExecutor js = (JavascriptExecutor)driver;
	js.executeScript("window.scrollBy(0,10000)");
	try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	WebElement i = driver.findElement(By.xpath("//img[@class='_396cs4 _3exPp9']"));
	Boolean p = (Boolean) ((JavascriptExecutor) driver).executeScript("return arguments[0].complete "
			+ "&& typeof arguments[0].naturalWidth != \"undefined\" " + "&& arguments[0].naturalWidth > 0", i);

	if (p) {
		System.out.println("Image is loaded");
	} else {
		System.out.println("Image not loaded");
	}
	
	try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	System.out.println("Scroll Down Process Working Fine");
	System.out.println("**********************************");	
	js.executeScript("window.scrollBy(0,-10000)");
	try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println("Scroll Up Process Working Fine");
	System.out.println("********************************");
	}
	
	}

		

