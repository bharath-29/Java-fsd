package package1;
import package1.bharath;

class bharath 
{ 
   private void KSR () 
    { 
        System.out.println(" welcome to all"); 
    } 
} 
public class privateaccess {
	public static void main(String[] args) {
		System.out.println("Welcome to all ");
		bharath  obj = new bharath(); 
	}
}
