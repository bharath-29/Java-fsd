package com.simplilearn.demo;

public class NestedLoopDemo {

	public static void main(String[] args) {
		
		for(int row=1; row<5 ;row ++) {
			//System.out.println("using for loop "+i);
		
			for(int col=1; col<5 ;col ++) {
				
				 System.out.print("* ");
		
			}
		
		
		}
				
		System.out.println();
		
		
	}
}
