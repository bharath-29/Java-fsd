package com.simplilearn.typecasting;

public class ExplicitTypeCasting {
	
	public static void main(String [] args) {
		
		double a= 23.67;
		
		int b=(int) a;  ///convert forcefully to int
		
		System.out.println("Converted Double "+a+" to int "+b);
		
	}

}
