package com.simplilearn.annonymousinner;

public interface Car {
	
	// interface in java is abstarct type which is used to describe behaviour 
	//it is blue print of class
	//interface in java is used to achieve abstarction
	
	public void start();
	public void stop();

}
