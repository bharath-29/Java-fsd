package com.simplilearn.uncheckedexceptions;

//runtime: ArrayIndexOutOfBoundsException:
public class Demo3 {
	
	public static void main(String[] args) {
		
		
		int array[]= {5,6,7,8,9};
		
		System.out.println(array[5]);
	}

}
