
										//Email validation//




import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.regex.*;
public class Emailvalidation {
public static void main(String[] args) {
String[]fg= {"^(.+)@(.+)$"};
String fg1 = null;
String str[] = {"plantbharath@gmail.com" , "bharath@gmail.com", "bharathravi@yahoo.com","bharathd@gmail.com"};
//String[] str2 = {"plantbharath@gmail.com" , "bharath@gmail.com", "bharathravi@gmail.com","bharathd@gmail.com"};
String i;
List<String> rrr =  new ArrayList<String>(Arrays.asList(str));
Scanner od = new Scanner(System.in);
System.out.println("Enter your mail : ");
String i1 = od.nextLine();
boolean win = rrr.contains(i1);
if(win) {
	System.out.println("Your Mail_id in the list" );}
else
System.out.println("Sorry your mail_id not in the list" );
}
}







