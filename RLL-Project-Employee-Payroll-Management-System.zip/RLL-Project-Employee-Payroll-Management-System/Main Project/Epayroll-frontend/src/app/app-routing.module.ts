import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddAmsComponent } from './components/admin/ams/add-ams/add-ams.component';
import { EditAmsComponent } from './components/admin/ams/edit-ams/edit-ams.component';
import { ListAmsComponent } from './components/admin/ams/list-ams/list-ams.component';
import { CnaComponent } from './components/admin/cna/cna.component';
import { DashboardComponent } from './components/admin/dashboard/dashboard.component';
import { EditEmsComponent } from './components/admin/ems/edit-ems/edit-ems.component';
import { ListEmsComponent } from './components/admin/ems/list-ems/list-ems.component';
import { NewEmsComponent } from './components/admin/ems/new-ems/new-ems.component';
import { LmsComponent } from './components/admin/lms/lms.component';
import { LoginComponent } from './components/admin/login/login.component';
import { EditSalaryComponent } from './components/admin/sms/edit-salary/edit-salary.component';
import { ListSmsComponent } from './components/admin/sms/list-sms/list-sms.component';
import { NewSmsComponent } from './components/admin/sms/new-sms/new-sms.component';
import { EditWssComponent } from './components/admin/wss/edit-wss/edit-wss.component';
import { ListWssComponent } from './components/admin/wss/list-wss/list-wss.component';
import { NewWssComponent } from './components/admin/wss/new-wss/new-wss.component';
import { EProfileComponent } from './components/employee/e-profile/e-profile.component';
import { EamsComponent } from './components/employee/eams/eams.component';
import { EdashboardComponent } from './components/employee/edashboard/edashboard.component';
import { EforgotComponent } from './components/employee/eforgot/eforgot.component';
import { ListElmsComponent } from './components/employee/elms/list-elms/list-elms.component';
import { NewElmsComponent } from './components/employee/elms/new-elms/new-elms.component';
import { EloginComponent } from './components/employee/elogin/elogin.component';
import { EregisterComponent } from './components/employee/eregister/eregister.component';
import { EresetpasswordComponent } from './components/employee/eresetpassword/eresetpassword.component';
import { ListEsmsComponent } from './components/employee/esms/list-esms/list-esms.component';
import { EwssComponent } from './components/employee/ewss/ewss.component';

const routes: Routes = [
  { path: '', component: EloginComponent },
  { path: 'employee/login', component: EloginComponent },
  { path: 'employee/signup', component: EregisterComponent },
  { path: 'employee/forgot', component: EforgotComponent },
  { path: 'employee/profile', component: EProfileComponent },

  { path: 'employee/dashboard', component: EdashboardComponent },
  { path: 'employee/wss', component: EwssComponent },
  { path: 'employee/ams', component: EamsComponent },
  { path: 'employee/lms', component: ListElmsComponent },
  { path: 'employee/lms/new', component: NewElmsComponent },

  { path: 'employee/sms', component: ListEsmsComponent },
  { path: 'employee/change-password', component: EresetpasswordComponent },
  { path: 'admin', component: LoginComponent },
  { path: 'admin/cna', component: CnaComponent },
  { path: 'admin/ams/edit/:id', component: EditAmsComponent },

  { path: 'admin/login', component: LoginComponent },
  { path: 'admin/dashboard', component: DashboardComponent },
  { path: 'admin/ems', component: ListEmsComponent },
  { path: 'admin/ems/new', component: NewEmsComponent },
  { path: 'admin/ems/edit/:id', component: EditEmsComponent },
  { path: 'admin/wss', component: ListWssComponent },
  { path: 'admin/wss/new', component: NewWssComponent },
  { path: 'admin/wss/edit/:id', component: EditWssComponent },
  { path: 'admin/ams', component: ListAmsComponent },
  { path: 'admin/ams/new', component: AddAmsComponent },

  { path: 'admin/lms', component: LmsComponent },

  { path: 'admin/sms', component: ListSmsComponent },
  { path: 'admin/sms/new', component: NewSmsComponent },
  { path: 'admin/sms/edit/:id', component: EditSalaryComponent },
  { path: 'admin/sms/edit/:id', component: EditSalaryComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
