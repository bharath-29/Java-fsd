import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EwssComponent } from './ewss.component';

describe('EwssComponent', () => {
  let component: EwssComponent;
  let fixture: ComponentFixture<EwssComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EwssComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EwssComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
