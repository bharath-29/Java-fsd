import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListElmsComponent } from './list-elms.component';

describe('ListElmsComponent', () => {
  let component: ListElmsComponent;
  let fixture: ComponentFixture<ListElmsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListElmsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListElmsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
