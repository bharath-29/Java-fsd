import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { map } from 'rxjs';
import { Attandance } from 'src/app/components/Attandance';
import { AttendStatus } from 'src/app/components/AttendStaus';
import { Salary } from 'src/app/components/Salary';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
@Component({
  selector: 'app-list-esms',
  templateUrl: './list-esms.component.html',
  styleUrls: ['./list-esms.component.css'],
})
export class ListEsmsComponent implements OnInit {
  math = Math;
  fetchedAttendStatus: any[] = [];
  fetchedsalary: Salary[] = [];
  fetchedAttendance: Attandance[] = [];
  backendurl = 'http://localhost:8081/salary';
  backendurl2 = 'http://localhost:8081/attandance';
  showPayslip = false;
  attendStatusArray: any;
  constructor(private http: HttpClient, private router: Router) {}
  isLoading = true;
  email = localStorage.getItem('email');
  ngOnInit(): void {
    this.fetchsalary();
  }
  fetchsalary() {
    this.http
      .get(this.backendurl + '/emp/' + localStorage.getItem('email'))
      .pipe(
        map((responseData) => {
          console.log(responseData);
          const salaryArray: Salary[] = [];
          for (const key in responseData) {
            var x = { ...(responseData as any)[key] };
            salaryArray.push(x);
          }
          this.isLoading = false;
          return salaryArray;
        })
      )
      .subscribe((salary) => {
        this.fetchedsalary = salary;
        console.log(salary);
      });
  }

  fetchAttandance(postData: { email: string; month: string }) {
    this.showPayslip = true;
    this.http
      .post(this.backendurl2 + '/status', postData)
      .pipe(
        map((responseData) => {
          console.log(responseData);
          var AttendStatus: any[] = [];
          var presentStatus = 0;
          var absentStatus = 0;
          for (const key in responseData) {
            var x = { ...(responseData as any)[key] };
            if (x.status == 'absent') {
              absentStatus++;
            } else {
              if (x.status == 'present') {
                presentStatus++;
              }
            }
          }
          AttendStatus.push(
            postData.month,
            Number(absentStatus),
            Number(presentStatus)
          );
          return AttendStatus;
        })
      )
      .subscribe((salary) => {
        this.fetchedAttendStatus = salary;
        console.log(salary);
      });
  }
  public openPDF(): void {
    let DATA: any = document.getElementById('htmlData');
    html2canvas(DATA).then((canvas) => {
      let fileWidth = 208;
      let fileHeight = (canvas.height * fileWidth) / canvas.width;
      const FILEURI = canvas.toDataURL('image/png');
      let PDF = new jsPDF('p', 'mm', 'a4');
      let position = 0;
      PDF.addImage(FILEURI, 'PNG', 0, position, fileWidth, fileHeight);
      PDF.save('payslip.pdf');
    });
  }
}
