import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from '../../Employee';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-e-profile',
  templateUrl: './e-profile.component.html',
  styleUrls: ['./e-profile.component.css'],
})
export class EProfileComponent implements OnInit {
  fetchedEmployee: Employee[] = [];
  backendurl = 'http://localhost:8081/employee';
  EmployeeById: any;
  successStatus: string | undefined;
  isLoading = false;
  id = localStorage.getItem('id');
  constructor(
    private activatedRoute: ActivatedRoute,
    private http: HttpClient,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.getEmployeeById();
  }

  getEmployeeById(): void {
    this.http
      .get<Request>(this.backendurl + '/' + this.id)
      .subscribe((data) => {
        this.EmployeeById = data;
        console.log(this.EmployeeById);
        console.log(this.id);
      });
  }
  onUpdateEmployee(
    postData: {
      id: number;
      fname: string;
      lname: string;
      email: string;
      department: string;
      phone: string;
      gender: string;
      joiningDate: string;
      password: string;
      age: string;
    },
    form: NgForm
  ) {
    this.isLoading = true;
    this.http.put(this.backendurl, postData).subscribe((responseData) => {
      console.log(responseData);
      alert('Profile Details has been successfully modified');
      this.router.navigate(['employee/dashboard']);
    });
  }
}
