import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-eresetpassword',
  templateUrl: './eresetpassword.component.html',
  styleUrls: ['./eresetpassword.component.css'],
})
export class EresetpasswordComponent implements OnInit {
  email = localStorage.getItem('email');
  constructor(private http: HttpClient, private router: Router) {}
  backendurl = 'http://localhost:8081/employee/reset';
  successStatus: string | undefined;
  isLoading = false;
  ngOnInit(): void {}
  onResetPassword(
    postData: {
      email: string;
      phone: string;
      password: string;
    },
    form: NgForm
  ) {
    this.http.post(this.backendurl, postData).subscribe((responseData) => {
      console.log('log' + responseData);
      this.isLoading = false;

      if (responseData) {
        this.successStatus = 'Password reseted Successfull';
        confirm(this.successStatus);
        {
          this.router.navigate(['']);
        }
      } else {
        alert(
          "Employee with email adress and phone doesn't match to any employee"
        );
      }
    });
  }
}
