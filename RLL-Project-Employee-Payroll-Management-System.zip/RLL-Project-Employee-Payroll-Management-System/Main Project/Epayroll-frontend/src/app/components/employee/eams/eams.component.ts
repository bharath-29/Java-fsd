import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { map } from 'rxjs';
import { Attandance } from '../../Attandance';

@Component({
  selector: 'app-eams',
  templateUrl: './eams.component.html',
  styleUrls: ['./eams.component.css'],
})
export class EamsComponent implements OnInit {
  fetchedAttendance: Attandance[] = [];
  backendurl = 'http://localhost:8081/attandance';
  constructor(private http: HttpClient, private router: Router) {}
  isLoading = true;

  ngOnInit(): void {
    this.fetchAttandance();
  }
  fetchAttandance() {
    this.http
      .get(this.backendurl + '/emp/' + localStorage.getItem('email'))
      .pipe(
        map((responseData) => {
          console.log(responseData);
          const AttandanceArray: Attandance[] = [];
          for (const key in responseData) {
            var x = { ...(responseData as any)[key] };
            AttandanceArray.push(x);
          }
          this.isLoading = false;
          return AttandanceArray;
        })
      )
      .subscribe((Attandances) => {
        this.fetchedAttendance = Attandances;
        console.log(Attandances);
      });
  }
}
