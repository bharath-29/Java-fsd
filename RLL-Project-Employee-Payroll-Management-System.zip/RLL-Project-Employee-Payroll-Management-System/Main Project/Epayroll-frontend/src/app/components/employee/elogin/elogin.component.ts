import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-elogin',
  templateUrl: './elogin.component.html',
  styleUrls: ['./elogin.component.css'],
})
export class EloginComponent implements OnInit {
  backendurl = 'http://localhost:8081/employee/login';
  successStatus: string | undefined;
  isLoading = false;
  emailError = false;
  passwordError = false;
  constructor(private router: Router, private http: HttpClient) {}

  ngOnInit(): void {
    if (localStorage.getItem('employeeLogin') === 'true') {
      this.router.navigate(['employee/dashboard']);
    }
  }

  onLogin(
    postData: {
      email: any;
      password: any;
    },
    form: NgForm
  ) {
    if (
      postData.email == '' ||
      postData.password == '' ||
      postData.email == null ||
      postData.password == null
    ) {
      if (postData.email == null || postData.email == '') {
        this.emailError = true;
        this.passwordError = false;
      }
      if (postData.password == null || postData.password == '') {
        this.passwordError = true;
        this.emailError = false;
      }
      if (
        ((postData.password == null || postData.password == '') &&
          postData.email == null) ||
        postData.email == ''
      ) {
        this.passwordError = true;
        this.emailError = true;
      }
    } else {
      this.http.post<any>(this.backendurl, postData).subscribe((res) => {
        console.log(res);
        if (res) {
          localStorage.setItem('employeeLogin', 'true');
          localStorage.setItem('email', res.email);
          localStorage.setItem('id', res.id);
          console.log(res.email);
          this.router.navigate(['employee/dashboard']);
        } else {
          alert('Invalid Credentials');
          form.reset();
        }
      });
    }
  }
}
