import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-eforgot',
  templateUrl: './eforgot.component.html',
  styleUrls: ['./eforgot.component.css'],
})
export class EforgotComponent implements OnInit {
  backendurl = 'http://localhost:8081/employee/reset';
  successStatus: string | undefined;
  isLoading = false;

  constructor(private router: Router, private http: HttpClient) {}

  ngOnInit(): void {
    if (localStorage.getItem('employeeLogin') == 'true') {
      this.router.navigate(['employee/dashboard']);
    }
  }

  onResetPassword(
    postData: {
      email: string;
      phone: string;
      password: string;
    },
    form: NgForm
  ) {
    this.isLoading = true;
    this.http.post(this.backendurl, postData).subscribe((responseData) => {
      console.log('log' + responseData);
      this.isLoading = false;

      if (responseData) {
        this.successStatus = 'Password reseted Successfull';
        confirm(this.successStatus);
        {
          this.router.navigate(['']);
        }
      } else {
        alert(
          "Employee with email adress and phone doesn't match to any employee"
        );
      }
    });
  }
}
