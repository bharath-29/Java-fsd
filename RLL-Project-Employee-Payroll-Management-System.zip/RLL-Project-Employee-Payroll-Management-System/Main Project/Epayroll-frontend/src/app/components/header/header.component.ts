import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent implements OnInit {
  constructor(private router: Router, private http: HttpClient) {}

  ngOnInit(): void {
    if (localStorage.getItem('adminLogin') == 'true') {
    } else {
      this.router.navigate(['admin']);
    }
  }
  onLogout() {
    localStorage.removeItem('adminLogin');
    this.router.navigate(['admin']);
  }
}
