export interface Leave {
  id: number;
  email: string;
  leaveFrom: string;
  leaveTo: string;
  reason: String;
  status: string;
}
