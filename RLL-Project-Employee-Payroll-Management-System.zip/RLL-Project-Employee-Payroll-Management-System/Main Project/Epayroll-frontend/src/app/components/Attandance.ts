export interface Attandance {
  id: number;
  email: string;
  attendanceDate: string;
  status: string;
  month: string;
  year: string;
}
