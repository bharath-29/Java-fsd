export interface AttendStatus {
  id: number;
  email: string;
  absentCount: string;
  presentCount: string;
}
