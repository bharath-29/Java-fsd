import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-eheader',
  templateUrl: './eheader.component.html',
  styleUrls: ['./eheader.component.css'],
})
export class EheaderComponent implements OnInit {
  constructor(private router: Router, private http: HttpClient) {}

  email = localStorage.getItem('email');
  id = localStorage.getItem('id');
  ngOnInit(): void {
    if (localStorage.getItem('employeeLogin') != 'true') {
      this.router.navigate(['']);
    }
  }

  onLogout() {
    localStorage.removeItem('employeeLogin');
    localStorage.removeItem('id');
    localStorage.removeItem('email');
    this.router.navigate(['']);
  }
}
