export interface Employee {
  id: number;
  fname: string;
  lname: string;
  email: string;
  password: String;
  department: string;
  phone: string;
  gender: string;
  joiningDate: string;
  age: string;
}
