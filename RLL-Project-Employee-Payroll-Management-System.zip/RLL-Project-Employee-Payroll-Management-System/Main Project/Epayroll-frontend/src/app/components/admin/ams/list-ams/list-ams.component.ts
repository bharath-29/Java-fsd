import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { map } from 'rxjs';
import { Attandance } from 'src/app/components/Attandance';

@Component({
  selector: 'app-list-ams',
  templateUrl: './list-ams.component.html',
  styleUrls: ['./list-ams.component.css'],
})
export class ListAmsComponent implements OnInit {
  fetchedAttendance: Attandance[] = [];
  backendurl = 'http://localhost:8081/attandance';
  constructor(private http: HttpClient, private router: Router) {}
  isLoading = true;

  ngOnInit(): void {
    this.fetchAttandance();
  }
  fetchAttandance() {
    this.http
      .get(this.backendurl)
      .pipe(
        map((responseData) => {
          console.log(responseData);
          const AttandanceArray: Attandance[] = [];
          for (const key in responseData) {
            var x = { ...(responseData as any)[key] };
            AttandanceArray.push(x);
          }
          this.isLoading = false;
          return AttandanceArray;
        })
      )
      .subscribe((Attandances) => {
        this.fetchedAttendance = Attandances;
        console.log(Attandances);
      });
  }

  onDelete(empId: number) {
    this.http
      .delete(this.backendurl + '/' + empId, { responseType: 'text' })
      .subscribe((res) => {
        if (res) {
          confirm('Attandance has been Deleted successfully');
          {
            location.reload();
          }
        } else {
          alert("Attandance doesn't exists");
        }
      });
  }
}
