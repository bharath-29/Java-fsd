import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddAmsComponent } from './add-ams.component';

describe('AddAmsComponent', () => {
  let component: AddAmsComponent;
  let fixture: ComponentFixture<AddAmsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddAmsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddAmsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
