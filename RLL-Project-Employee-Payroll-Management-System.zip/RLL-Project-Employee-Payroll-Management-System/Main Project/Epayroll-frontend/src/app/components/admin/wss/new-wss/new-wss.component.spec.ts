import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewWssComponent } from './new-wss.component';

describe('NewWssComponent', () => {
  let component: NewWssComponent;
  let fixture: ComponentFixture<NewWssComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NewWssComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NewWssComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
