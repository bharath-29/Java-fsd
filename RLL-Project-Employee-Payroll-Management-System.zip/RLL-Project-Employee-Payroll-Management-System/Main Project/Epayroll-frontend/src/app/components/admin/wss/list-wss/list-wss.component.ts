import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { map } from 'rxjs';
import { Work } from 'src/app/components/Work';

@Component({
  selector: 'app-list-wss',
  templateUrl: './list-wss.component.html',
  styleUrls: ['./list-wss.component.css'],
})
export class ListWssComponent implements OnInit {
  fetchedWork: Work[] = [];
  backendurl = 'http://localhost:8081/work';
  constructor(private http: HttpClient, private router: Router) {}
  isLoading = true;

  ngOnInit(): void {
    this.fetchWork();
  }
  fetchWork() {
    this.http
      .get(this.backendurl)
      .pipe(
        map((responseData) => {
          console.log(responseData);
          const WorkArray: Work[] = [];
          for (const key in responseData) {
            var x = { ...(responseData as any)[key] };
            WorkArray.push(x);
          }
          this.isLoading = false;
          return WorkArray;
        })
      )
      .subscribe((Works) => {
        this.fetchedWork = Works;
        console.log(Works);
      });
  }

  onDelete(workId: number) {
    this.http
      .delete(this.backendurl + '/' + workId, { responseType: 'text' })
      .subscribe((res) => {
        if (res) {
          confirm('Work has been Deleted successfully');
          {
            location.reload();
          }
        }
      });
  }
}
