import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { map } from 'rxjs';
import { Salary } from 'src/app/components/Salary';

@Component({
  selector: 'app-list-sms',
  templateUrl: './list-sms.component.html',
  styleUrls: ['./list-sms.component.css'],
})
export class ListSmsComponent implements OnInit {
  fetchedsalary: Salary[] = [];
  backendurl = 'http://localhost:8081/salary';
  constructor(private http: HttpClient, private router: Router) {}
  isLoading = true;

  ngOnInit(): void {
    this.fetchsalary();
  }
  fetchsalary() {
    this.http
      .get(this.backendurl)
      .pipe(
        map((responseData) => {
          console.log(responseData);
          const salaryArray: Salary[] = [];
          for (const key in responseData) {
            var x = { ...(responseData as any)[key] };
            salaryArray.push(x);
          }
          this.isLoading = false;
          return salaryArray;
        })
      )
      .subscribe((salary) => {
        this.fetchedsalary = salary;
        console.log(salary);
      });
  }

  onDelete(empId: number) {
    this.http
      .delete(this.backendurl + '/' + empId, { responseType: 'text' })
      .subscribe((res) => {
        if (res) {
          confirm('salary has been Deleted successfully');
          {
            location.reload();
          }
        } else {
          alert("salary doesn't exists");
        }
      });
  }
}
