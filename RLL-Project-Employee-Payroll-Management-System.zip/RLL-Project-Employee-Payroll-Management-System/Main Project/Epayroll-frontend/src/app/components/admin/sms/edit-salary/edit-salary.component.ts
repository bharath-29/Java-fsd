import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { map } from 'rxjs';
import { Employee } from 'src/app/components/Employee';
import { Salary } from 'src/app/components/Salary';

@Component({
  selector: 'app-edit-salary',
  templateUrl: './edit-salary.component.html',
  styleUrls: ['./edit-salary.component.css'],
})
export class EditSalaryComponent implements OnInit {
  SalaryById: any;
  id: string | undefined;
  fetchedEmployees: Employee[] = [];

  backendurl = 'http://localhost:8081/salary';
  backendurl2 = 'http://localhost:8081/employee';
  successStatus: string | undefined;
  isLoading = false;
  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private http: HttpClient
  ) {}

  ngOnInit(): void {
    this.fetchEmployee();
    this.id = this.activatedRoute.snapshot.paramMap.get('id') as string;

    this.getSalaryById(this.id);
  }

  fetchEmployee() {
    this.http
      .get(this.backendurl2)
      .pipe(
        map((responseData) => {
          console.log(responseData);
          const EmployeeArray: Employee[] = [];
          for (const key in responseData) {
            var x = { ...(responseData as any)[key] };
            EmployeeArray.push(x);
          }
          this.isLoading = false;
          return EmployeeArray;
        })
      )
      .subscribe((Employees) => {
        this.fetchedEmployees = Employees;
        console.log(Employees);
      });
  }

  getSalaryById(id: string): void {
    this.http
      .get<Request>(this.backendurl + '/' + this.id)
      .subscribe((data) => {
        this.SalaryById = data;
      });
  }
  onUpdateSalary(
    postData: {
      id: number;
      email: string;
      salary: string;
    },
    form: NgForm
  ) {
    this.isLoading = true;
    this.http.put(this.backendurl, postData).subscribe((responseData) => {
      console.log(responseData);
      if (responseData) {
        alert('Salary has been successfully modified');
        this.router.navigate(['admin/sms']);
      } else {
        alert('Salary already exists');
      }
    });
  }
}
