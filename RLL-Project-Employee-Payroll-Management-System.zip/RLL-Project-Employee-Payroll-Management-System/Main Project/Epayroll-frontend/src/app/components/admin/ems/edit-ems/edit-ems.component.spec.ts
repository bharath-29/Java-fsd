import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditEmsComponent } from './edit-ems.component';

describe('EditEmsComponent', () => {
  let component: EditEmsComponent;
  let fixture: ComponentFixture<EditEmsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditEmsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditEmsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
