import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListEmsComponent } from './list-ems.component';

describe('ListEmsComponent', () => {
  let component: ListEmsComponent;
  let fixture: ComponentFixture<ListEmsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListEmsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListEmsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
