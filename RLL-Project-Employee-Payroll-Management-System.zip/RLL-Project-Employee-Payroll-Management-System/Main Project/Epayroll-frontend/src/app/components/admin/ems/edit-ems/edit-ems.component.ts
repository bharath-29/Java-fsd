import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from 'src/app/components/Employee';

@Component({
  selector: 'app-edit-ems',
  templateUrl: './edit-ems.component.html',
  styleUrls: ['./edit-ems.component.css'],
})
export class EditEmsComponent implements OnInit {
  fetchedEmployee: Employee[] = [];
  backendurl = 'http://localhost:8081/employee';
  EmployeeById: any;
  successStatus: string | undefined;
  isLoading = false;
  id: string | undefined;
  constructor(
    private activatedRoute: ActivatedRoute,
    private http: HttpClient,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.id = this.activatedRoute.snapshot.paramMap.get('id') as string;
    this.getEmployeeById(this.id);
  }

  getEmployeeById(id: string): void {
    this.http
      .get<Request>(this.backendurl + '/' + this.id)
      .subscribe((data) => {
        this.EmployeeById = data;
        console.log(this.EmployeeById);
      });
  }
  onUpdateEmployee(
    postData: {
      id: number;
      fname: string;
      lname: string;
      email: string;
      department: string;
      phone: string;
      gender: string;
      joiningDate: string;
      password: string;
      age: string;
    },
    form: NgForm
  ) {
    this.isLoading = true;
    this.http.put(this.backendurl, postData).subscribe((responseData) => {
      console.log(responseData);
      alert('Employee has been successfully modified');
      this.router.navigate(['admin/ems']);
    });
  }
}
