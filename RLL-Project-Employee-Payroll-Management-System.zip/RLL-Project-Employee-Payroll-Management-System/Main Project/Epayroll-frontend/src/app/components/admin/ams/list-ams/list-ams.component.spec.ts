import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListAmsComponent } from './list-ams.component';

describe('ListAmsComponent', () => {
  let component: ListAmsComponent;
  let fixture: ComponentFixture<ListAmsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ListAmsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ListAmsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
