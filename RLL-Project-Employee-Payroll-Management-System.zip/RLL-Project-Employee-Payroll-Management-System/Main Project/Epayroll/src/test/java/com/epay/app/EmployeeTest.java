package com.epay.app;

import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.epay.app.modal.Employee;
import com.epay.app.modal.Attendance;
import com.epay.app.modal.Leaves;
import com.epay.app.modal.Salary;
import com.epay.app.modal.WorkSchedule;

import com.epay.app.repository.EmployeeRepository;
import com.epay.app.repository.AttendanceRepository;
import com.epay.app.repository.LeavesRepository;
import com.epay.app.repository.SalaryRepository;
import com.epay.app.repository.WorkScheduleRepository;

@SpringBootTest
class EmployeeTest {

    @Autowired
    EmployeeRepository employeeRepository;

    @Test
    @Order(1)
    void Signup() {
        System.out.println("\n\n-----------------------------------\n\n");
        System.out.println("Employee Signup. Please wait...");
        System.out.println("\n\n-----------------------------------\n\n");

        Employee emp = new Employee();
        emp.setFname("Ram");
        emp.setLname("Sharma");
        emp.setEmail("Ram.sharma@rll.com");
        emp.setPhone("9999999999");
        emp.setPassword("Ram@1234");
        emp.setJoiningDate("2022-12-10");
        emp.setDepartment("Tester");
        emp.setAge("23");
        emp.setGender("Male");

        if (employeeRepository.existsByEmailOrPhone(emp.getEmail(), emp.getPhone())) {
            System.out.println("\n\n-----------------------------------\n\n");
            System.out.println("Employee Already exists...");
            System.out.println("\n\n-----------------------------------\n\n");
        } else {
            employeeRepository.save(emp);
            System.out.println("\n\n-----------------------------------\n\n");
            System.out.println("Employee Signup successfull...");
            System.out.println("\n\n-----------------------------------\n\n");
        }
    }

    @Test
    @Order(2)
    void resetPassword() {
        System.out.println("\n\n-----------------------------------\n\n");
        System.out.println("Employee Reset Password. Please wait...");
        System.out.println("\n\n-----------------------------------\n\n");
        Employee emp = new Employee();
        emp.setEmail("Ram.sharma@rll.com");
        emp.setPhone("9999999999");
        emp.setPassword("Ram@123456");
        if (employeeRepository.existsByEmailAndPhone(emp.getEmail(), emp.getPhone())) {
            employeeRepository.resetPassword(emp.getEmail(), emp.getPhone(), emp.getPassword());
            System.out.println("\n\n-----------------------------------\n\n");
            System.out.println("Employee password resetted successfull...");
            System.out.println("\n\n-----------------------------------\n\n");
        } else {
            System.out.println("\n\n-----------------------------------\n\n");
            System.out.println("Employee email and phone do not match...");
            System.out.println("\n\n-----------------------------------\n\n");
        }

    }

    @Test
    @Order(3)
    void login() {
        System.out.println("\n\n-----------------------------------\n\n");
        System.out.println("Employee Login. Please wait...");
        System.out.println("\n\n-----------------------------------\n\n");
        Employee emp = new Employee();
        emp.setEmail("Ram.sharma@rll.com");
        emp.setPassword("Ram@123456");
        if (employeeRepository.existsByEmailAndPassword(emp.getEmail(), emp.getPassword())) {
            System.out.println("\n\n-----------------------------------\n\n");
            System.out.println("Employee Logged successfull...");
            System.out.println("\n\n-----------------------------------\n\n");
        } else {
            System.out.println("\n\n-----------------------------------\n\n");
            System.out.println("Invalid Credentials...");
            System.out.println("\n\n-----------------------------------\n\n");
        }
    }

    @Test
    @Order(4)
    void getAllEmployees() {
        System.out.println("\n\n-----------------------------------\n\n");

        System.out.println("Getting all employees...");

        System.out.println("\n\n-----------------------------------\n\n");

        System.out.println(employeeRepository.findAll());
        System.out.println("\n\n-----------------------------------\n\n");

    }

    @Test
    @Order(5)
    void updateEmployee() {
        System.out.println("\n\n-----------------------------------\n\n");
        System.out.println("Employee Signup. Please wait...");
        System.out.println("\n\n-----------------------------------\n\n");

        Employee emp = new Employee();
        emp.setId(1L);
        emp.setFname("Ram");
        emp.setLname("Sharma");
        emp.setEmail("Ram.sharma@rll.com");
        emp.setPhone("9999999999");
        emp.setPassword("Ram@1234");
        emp.setJoiningDate("2022-12-10");
        emp.setDepartment("Tester");
        emp.setAge("23");
        emp.setGender("Male");

        if (employeeRepository.existsByEmailOrPhone(emp.getEmail(), emp.getPhone())) {
            System.out.println("\n\n-----------------------------------\n\n");
            System.out.println("Employee with email and password Already exists...");
            System.out.println("\n\n-----------------------------------\n\n");
        } else {
            employeeRepository.save(emp);
            System.out.println("\n\n-----------------------------------\n\n");
            System.out.println("Employee updated successfull...");
            System.out.println("\n\n-----------------------------------\n\n");
        }
    }

    @Test
    @Order(6)
    void getEmployeeById() {
        System.out.println("\n\n-----------------------------------\n\n");

        System.out.println("Get  Employee By Id...");

        System.out.println("\n\n-----------------------------------\n\n");
        if (employeeRepository.existsById(1L)) {
            System.out.println(employeeRepository.findById(1L));
        }
        System.out.println("Employee with id 1 doesn't exists");
        System.out.println("\n\n-----------------------------------\n\n");
    }

    @Autowired
    LeavesRepository applyleave;

    @Test
    @Order(8)
    void applyleave() {
        System.out.println("\n\n-----------------------------------\n\n");
        System.out.println("Employee Signup. Please wait...");
        System.out.println("\n\n-----------------------------------\n\n");

        Leaves leave = new Leaves();
        leave.setEmail("Kumar@gmail.com");
        leave.setEmpId(123);
        leave.setLeaveFrom("12.3.2020");
        leave.setLeaveTo("17.3.2020");
        leave.setReason("Fever");
        leave.setStatus("not good");
        if (applyleave.existsById(leave.getEmpId())) {

            System.out.println("\n\n-----------------------------------\n\n");
            System.out.println("Employee Already exists...");
            System.out.println("\n\n-----------------------------------\n\n");
        } else {
            applyleave.save(leave);
            System.out.println("\n\n-----------------------------------\n\n");
            System.out.println("Employee Signup successfull...");
            System.out.println("\n\n-----------------------------------\n\n");

        }

    }

    @Autowired
    SalaryRepository salaryrepository;

    @Test
    @Order(9)
    void getAllsalary() {
        System.out.println("\n\n-----------------------------------\n\n");

        System.out.println("Getting salary...");

        System.out.println("\n\n-----------------------------------\n\n");

        System.out.println(salaryrepository.findAll());
        System.out.println("\n\n-----------------------------------\n\n");

    }

    @Autowired
    WorkScheduleRepository worschedulerepository;

    @Test
    @Order(10)
    void getAllwork() {
        System.out.println("\n\n-----------------------------------\n\n");

        System.out.println("Getting work...");

        System.out.println("\n\n-----------------------------------\n\n");

        System.out.println(worschedulerepository.findAll());
        System.out.println("\n\n-----------------------------------\n\n");

    }

}