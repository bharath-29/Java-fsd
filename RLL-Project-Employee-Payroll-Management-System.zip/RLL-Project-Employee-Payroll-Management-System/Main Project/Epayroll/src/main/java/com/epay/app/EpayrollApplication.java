package com.epay.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EpayrollApplication {

	public static void main(String[] args) {
		SpringApplication.run(EpayrollApplication.class, args);
	}

}
