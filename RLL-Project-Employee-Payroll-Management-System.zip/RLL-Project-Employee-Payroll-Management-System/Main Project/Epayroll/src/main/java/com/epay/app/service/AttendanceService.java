package com.epay.app.service;

import java.util.Optional;

import com.epay.app.modal.Attendance;

public interface AttendanceService {

	Boolean saveAttendance(Attendance attandance);

	Iterable<Attendance> getAttendance();

	Boolean deleteAttendence(int id);

	Iterable<Attendance> getAttendanceByEmail(String email);

    Iterable<Attendance> getAttandanceByMonth(Attendance attendance);

    Boolean updateAttendance(Attendance attendance);

    Optional<Attendance> getAttendenceById(int id);

}
