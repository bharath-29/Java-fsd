package com.epay.app.service;

import com.epay.app.modal.Admin;

public interface AdminService {

	boolean login(Admin admin);

    boolean signup(Admin admin);

}
