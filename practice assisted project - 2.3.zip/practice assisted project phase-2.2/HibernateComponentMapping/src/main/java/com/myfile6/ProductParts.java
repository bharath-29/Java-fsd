package com.simplilearn;

public class ProductParts {
	
	private String mine;
	private String cpu;
	private String val;
	public String getMine() {
		return mine;
	}
	public void setHdd(String mine) {
		this.mine = mine;
	}
	public String getCpu() {
		return cpu;
	}
	public void setCpu(String cpu) {
		this.cpu = cpu;
	}
	public String getRam() {
		return val;
	}
	public void setRam(String ram) {
		this.val = val;
	}
	
	 
	
	

}
