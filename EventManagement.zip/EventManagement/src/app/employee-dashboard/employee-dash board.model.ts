export class EmployeeModel{
    id : number = 0;
    userName : string = '';

    email : string = '';
    mobile : string = '';

  // department: string='';
}
