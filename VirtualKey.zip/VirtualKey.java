import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
public class VirtualKey {
	public static void main(String[] args) throws IOException {
		toploop:
		while(true) {
		 System.out.println("\n*********************************************************************\n");
	        System.out.println("\t Welcome to The Virtual key Application \n");
	        System.out.println("\t Developer Name : BHARATH RAVINDRAN \n");
	        System.out.println("********************************************************************\n");
	        while(true){
	            System.out.println("1. To display the files in ascending order\n");
	            System.out.println("2. Here are some Business-level operations  \n");
	            System.out.println("3. Terminate Program\n");
	            System.out.print("Enter your option : ");
                Scanner g = new Scanner(System.in);
	            int choice = g.nextInt();
	            switch(choice)
	            {
	            case 1:
	            	// Shows path for mention file location//
	            	System.out.println("The File Name displays ascending order with path for identify location.....\n");
	            	File ff = new File("C:\\Users\\admin\\Desktop\\arch\\");
				    File[] cok = ff.listFiles();			
                    Arrays.sort(cok);
                    for(int i=0;i<cok.length;i++) {
                        System.out.println(cok[i]);
                    }
                    break;
	            case 2:
	            	boolean ch = true;
	            	while(ch==true) {
	            		System.out.println("1. I want create a new file \n");
	            		System.out.println("2. I want delete a file\n");
	            		System.out.println("3. I want search a file\n");
	            		System.out.println("4. Go to main menu\n");
	            		System.out.print("Enter your choice : ");
	            		int bhd = g.nextInt();
	            	switch(bhd) {
	            	case 1:
	            		System.out.print("Enter file name : ");
                		Scanner n = new Scanner(System.in);
                		String v = n.nextLine();
                		String folder = null;
                		if(new File(folder,v).exists()){
                            System.out.println("file already exist\n");
                        }else {
                            File folder1 = new File(folder, v);
                            folder1.mkdir();
                		File bh = new File(v+".txt");
                		File ff2 = new File("C:\\Users\\admin\\Desktop\\arch\\"+bh);
                		
							ff2.createNewFile();
						
                		System.out.println("File created Sucessfully please the folder....\n");
                        }
				break;
	            	case 2:
	            		
	            		Scanner dw = new Scanner(System.in);
                    	System.out.print("Enter a File Name : ");
                    	String sd = dw.nextLine();
                    	File fr = new File(sd+".txt");
                    	File co = new File("C:\\\\Users\\\\admin\\\\Desktop\\\\arch\\\\"+fr);
                    	if(co.delete()) {
                    		System.out.println(co.getName()+" file deleted Sucessfully...\n");
                    	}
                    	else {
                    		System.out.println("File alredy deleted Sucessfully please check it.......\n");
                    	}
	            	break;
	            case 3:
	            	Scanner gm =  new Scanner(System.in);
                	System.out.print("Enter a File Name : ");
                	String gf = gm.nextLine();
                	File bha = new File("C:\\\\\\\\Users\\\\\\\\admin\\\\\\\\Desktop\\\\\\\\arch\\\\\\\\");
                	File array [] = bha.listFiles();
                	int i =0;
            		int length = array.length;
            		boolean found = false;
            		while(i<array.length) {
            	        	if(array[i].getName().startsWith(gf)) {
            	        		System.out.print("File founded Sucessfully...\n");
            	        		System.out.println("\n");
            	        	  found=true;
            	        		i= array.length;
            	        	}
            	        	else {
            	        		i++;
            	        	}
            		 }
				if(found==false) {
            	        	System.out.println("File not found\n");
            		 }
	           break;
	           
	            case 4 :
	            	ch = !true;
	            	System.out.println("Back to main page\n");
	            	break;
	            	}
	            	}break;
	            	
	            case 3:
	            	System.out.println("Thank you for using Application closed Sucessfully...");
	            	 break toploop;
	        }
	}
	}}}
