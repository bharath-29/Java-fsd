import java.util.Arrays;

public class mergeSort {

	public static void merge(int[] array) {
		merge(array, 0, array.length-1);
	}

	private static void merge(int[] array, int first, int last) {
		if(first < last) {
			int mi = (first+last)/2;
			merge(array, first, mi);
			merge(array, mi+1, last);
			merge(array, first, mi, last);
		}
	}

	public static void merge(int[] array, int start, int mi, int end) {
		int n1 = mi - start + 1;
		int n2 = end - mi;
		
		int[] temp1 = new int[n1];
		int[] temp2 = new int[n2];
		
		for(int i = 0; i < n1; i++) {
			temp1[i] = array[start+i];
		}
		
		for(int j = 0; j < n2; j++) {
			temp2[j] = array[mi+j+1];
		}
		
		int i = 0, j = 0, k = start;
		while(i < n1 && j < n2) {
			if(temp1[i] <= temp2[j]) {
				array[k] = temp1[i];
				i++;
			} else {
				array[k] = temp2[j];
				j++;
			}
			k++;
		}
		
		while(i < n1) {
			array[k] = temp1[i];
			i++;
			k++;
		}
		while(j < n2) {
			array[k] = temp2[j];
			j++;
			k++;
		}
	}
	
	public static void main(String[] args) {
		int[] array = {12, 35, 87, 26, 9, 28, 7};
		merge(array);
		System.out.println(Arrays.toString(array));
	}
}