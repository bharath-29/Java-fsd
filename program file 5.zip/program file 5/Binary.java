import java.util.Scanner;
public class Binary {
    public static  void main(String[] args){
        int[] array = {1,2,4,9,100,202,1000};
        Scanner n = new Scanner(System.in);
        System.out.println("Enter number : ");
        int val ;
        val = n.nextInt();
        int length = array.length;
        binaryof(array,0,val,length);
    }
public static void binaryof(int[] array, int max, int val2, int length){
        int midd = (max+length)/2;
        while(max<=length){

            if(array[midd]<val2){
                max = midd + 1;
            } else if(array[midd]== val2){
                System.out.println("index of value is  :"+midd);
                break;
            }else {

                length=midd-1;
            }
            midd = (max+length)/2;
        }
            
}

}
