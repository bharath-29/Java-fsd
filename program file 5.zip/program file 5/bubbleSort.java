public class bubbleSort{
  public static void bubble(int raw[]) {
    for(int i=0; i<raw.length; i++) {
      for(int j=0; j<raw.length-i-1; j++) {
        if(raw[j] > raw[j+1]) {
          int temp = raw[j];
          raw[j] = raw[j+1];
          raw[j+1] = temp;
        }
      }
    }
  }

  public static void main(String[] args) {
    int raw[] = {1, 3, 5, 2, 13, 4, 23, 12, 34, 120};
    bubble(raw);
    for(int i=0; i<10; i++) {
      System.out.print(raw[i] + " ");
    
  }

}}