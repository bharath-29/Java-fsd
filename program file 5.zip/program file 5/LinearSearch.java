import java.util.Scanner;

public class LinearSearch{
	public static void main(String[]args) {
	int val[]= {1,2,3,67,23,99};
	int a,b,c;
	Scanner mn = new Scanner(System.in);
	System.out.println("The List of arrays : ");
	for(a=0;a<val.length;a++) {
		System.out.println(val[a]+"");
		
	}
	System.out.println("Enter number Search : ");
	b=mn.nextInt();
	c=0;
	for(a=0;a<val.length;a++) {
		if(b==val[a]) {
			System.out.println("The number in the list and the index is : "+a);
			c=1;
			break;
		}
	}
	if(c==0) {
		System.out.println("Not in the list");
	}
}
}