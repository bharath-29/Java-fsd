import java.util.*;

public class collection {

	public static void main(String[] args) {
						System.out.println("Names");
				ArrayList<String> man=new ArrayList<String>();   
			      man.add("Praveen");
			      man.add("kumar");    	   
			      System.out.println(man);
			}
		
	}


