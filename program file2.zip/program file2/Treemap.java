import java.util.TreeMap;
import java.util.Map.Entry;
public class Treemap {
	public static void main(String[] args) {
		TreeMap<Integer,String> course = new TreeMap<Integer,String>();    
		   course.put(1 , "Html");    
		   course.put(2 , "Java");    
		   course.put(3 , "Angular");       
		      
		   System.out.println("The course are :  ");  
		   for(Entry<Integer, String> study : course.entrySet()){    
		    System.out.println(study.getKey() + " " + study.getValue()); 		
		
	}

}

	}


