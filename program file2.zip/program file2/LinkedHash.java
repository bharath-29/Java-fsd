import java.util.LinkedHashSet;
public class LinkedHash{
	public static void main(String[] args) {
	       System.out.println("LinkedHashSet");
	       LinkedHashSet<Integer> bh=new LinkedHashSet<Integer>();  
	       bh.add(100);  
	       bh.add(200);  
	       bh.add(300);	       
	       System.out.println(bh);
	      	} 

	
	}

