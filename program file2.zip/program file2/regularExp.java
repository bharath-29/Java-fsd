import java.util.regex.*;
public class regularExp {
	public static void main(String[] args) {
			String start = "[a-z]+";
			String check = "Iam , Bharath";
			System.out.println("The string : "+start+check);
			Pattern doll = Pattern.compile(start);
			Matcher window = doll.matcher(check);
			while (window.find())
		      	System.out.println( check.substring( window.start(), window.end() ) );
			}
		

	

}
