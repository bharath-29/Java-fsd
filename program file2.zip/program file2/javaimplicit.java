

								// Implicit//


public class javaimplicit {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Implicit program 
		byte val1 = 29;
		System.out.println("The byte value is : " +val1);
		short val2 = val1;
		System.out.println("The byte to short is : " +val2);
		int val3 = val2;
		System.out.println("The short to int is : " +val3);
		long val4 = val3;
		System.out.println("The int to long is :" +val4);
		float val5 = val4;
		System.out.println("The long to float is :" +val5);
		double val6 = val5;
		System.out.println("The float to double is :" +val6);
		

	}

}
