
// way of calling methods two type :
 // call by value and method overloading

// 1.call by value:

public class callbyValue {
	public static void main(String[] args) {
		int value=20;
		System.out.println("The value is : " +value);
		++value;
		System.out.println("The increment value " +value);
	}
	public static void meth(int bh) {
		System.out.println("The before increment value :  " +bh);
		bh = bh+1;
		System.out.println("The after value : " +bh);
	}
	

}
