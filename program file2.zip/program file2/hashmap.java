import java.util.HashMap;
import java.util.Map.Entry;
public class hashmap {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer,String> ksr = new HashMap<Integer,String>();
		ksr.put(1813008,"bharath");
		ksr.put(1813015,"Dhanush");
		ksr.put(1813019,"Gokul");
		for(Entry<Integer, String> key : ksr.entrySet()) {
			System.out.println(key+ksr.get(key));
	}
}
}