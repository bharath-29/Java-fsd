
public class Innerclass {
	private static void meth1() {
		System.out.println("First inner class");
		
	}
	static class inner{
		public static void meth2() {
			System.out.println("Second inner class ");
			meth1();
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Innerclass.inner obj = new Innerclass.inner();
		obj.meth2();

	}

}

