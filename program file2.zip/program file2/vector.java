import java.util.Vector;
public class vector {
	public static void main(String[] args) {
		
		    System.out.println("Vector");
		    Vector<Integer> values = new Vector();
		    values.add(100); 
		    values.add(300);
		    for(int value : values) {
		    System.out.println(values);
		    }
		}
	}
