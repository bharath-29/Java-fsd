class ak {
		int num ;
		int num2;
		int num3;
		
		ak(){
			num = 8;
			num2 = 15;
			num3 = 29;
		}
		int def() {
			return num+num2+num3;
		}
}
public class Constructor{
	public static void main(String[] args) {
		ak val = new ak();
		int def;
		def = val.def();
		System.out.println("The value is : " +def);
		
	}
	
}