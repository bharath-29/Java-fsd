
                                   //methodOverloading //

public class methodOverloading {
	public int multi(int a,int b) {
		return a*b;
	}
	public int multi(int a,int b, int c) {
		return a*b*c;
	}

	public static void main(String[] args) {
		methodOverloading methodOverloading = new methodOverloading();
		int a=20,b=30,c=40;
		System.out.println(methodOverloading.multi(a,b));
		System.out.println(methodOverloading.multi(a,b,c));
		
	}

}
