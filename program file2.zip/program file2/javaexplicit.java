


// Explicit program//


public class javaexplicit {

	public static void main(String[] args) {		
		double a = 75.0d;
		System.out.println("double value is : " +a);
		float b = (float)a;
		System.out.println("float value is : " +b);
		long c = (long)b;
		System.out.println("long value is : " +c);
		int d = (int)c;
		System.out.println("int value is : " +d);
		short e = (short)d;
		System.out.println("Short value is :" +e);
		byte f = (byte)e;
		System.out.println("byte value is : " +f);
		
		
	}

}
