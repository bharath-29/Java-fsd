import java.util.Scanner;
public class  Longestsub{
    public int[] list(int[] a)
    {        
        int num = a.length - 1;
        int[] Man = new int[num + 1];  
        int[] Past = new int[num + 1]; 
        int Ltv = 0;
        for (int i = 1; i < num + 1; i++)
        {
            int j = 0;
            for (int dark = Ltv ; dark >= 1; dark--)
            {
                if (a[Man[dark]] < a[i])
                {
                    j = dark;
                    break;
                }
            }            
            Past[i] = Man[j];
            if (j == Ltv || a[i] < a[Man[j + 1]])
            {
                Man[j + 1] = i;
                Ltv = Math.max(Ltv,j + 1);
            }
        }
        int[] result = new int[Ltv];
        int past = Man[Ltv];
        for (int i = Ltv - 1; i >= 0; i--)
        {
            result[i] = a[past];
            past = Past[past];
        }
        return result;             
    }
    public static void main(String[] args) 
    {    
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter how many numbers you want : ");
        int n = scan.nextInt();
        int[] arr = new int[n + 1];
        System.out.println("Enter elements");
        for (int i = 1; i <= n; i++)
            arr[i] = scan.nextInt();
        Longestsub obj = new Longestsub(); 
        int[] result = obj.list(arr);       
        System.out.print("Longest Increasing value is : ");
        for (int i = 0; i < result.length; i++)
            System.out.print(result[i] +" ");
        System.out.println();
    }
}