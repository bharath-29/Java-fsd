package webapp;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
public class AutomatedWebApp {
		WebDriver driver;
			@Test
	public void simple() {

		System.out.println("Welcome to automate web application");
		System.out.println("*************************************");
		System.out.println("Testng running successfully....");
		driver.get("https://www.amazon.in/ap/signin?openid.pape.max_auth_age=900&openid.return_to=https%3A%2F%2Fwww.amazon.in%2Fgp%2Fyourstore%2Fhome%3Fpath%3D%252Fgp%252Fyourstore%252Fhome%26signIn%3D1%26useRedirectOnSuccess%3D1%26action%3Dsign-out%26ref_%3Dnav_AccountFlyout_signout&openid.assoc_handle=inflex&openid.mode=checkid_setup&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0");
		driver.findElement(By.xpath("//input[@type='email']")).sendKeys("plantbharath@gmail.com");
		driver.findElement(By.xpath("//input[@id='continue']")).click();
		driver.findElement(By.xpath("//input[@type='password']")).sendKeys("Bharath@29");
		driver.findElement(By.id("auth-signin-button-announce")).submit();
	
			}
	@BeforeMethod
	public void beforeMethod() {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver= new ChromeDriver();
		
	}
	@AfterMethod
	public void afterMethod() {
		
		WebElement searchbox = driver.findElement(By.id("twotabsearchtextbox"));
		searchbox.sendKeys("Lenovo laptops");
		driver.findElement(By.xpath("//*[@id='nav-search-submit-button']")).click();
		driver.findElement(By.linkText("Lenovo IdeaPad Slim 3 11th Gen Intel Core i5 15.6\" (39.62cm) FHD Laptop (8GB/512GB SSD/Win 11/Office 2021/2 Year Warranty/Alexa Built-in/3 Month Game Pass/Arctic Grey/1.65Kg), 82H802KYIN")).click();
		driver.get("https://www.amazon.in/Lenovo-IdeaPad-39-62cm-Warranty-82H802KYIN/dp/B0BB6S9FR5/ref=sr_1_5?keywords=Lenovo%2Blaptops&qid=1664695812&qu=eyJxc2MiOiI3LjA1IiwicXNhIjoiNi45OCIsInFzcCI6IjQuNzcifQ%3D%3D&sr=8-5&th=1");
		driver.findElement(By.xpath("//*[@id=\"add-to-cart-button\"]")).click();
		
	
	}
	
}
