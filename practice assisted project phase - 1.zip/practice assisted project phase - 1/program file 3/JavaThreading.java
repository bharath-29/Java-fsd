public class JavaThreading extends Thread
{
 	public void run()
 	{
  		System.out.println("Thread runs sucessfully ");
}
 	public static void main( String args[] )
 	{
  		JavaThreading thrd = new  JavaThreading();
  		thrd.start();
 	}
}
  

                   