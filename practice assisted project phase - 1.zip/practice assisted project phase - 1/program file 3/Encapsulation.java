public class Encapsulation
{
    private String Name;
    private int Id;
    private int age;
    public int getAge ()
    {
        return age;
    }
    public String getName ()
    {
        return Name;
    }
    public int getRoll ()
    {
        return Id;
    }
    public void setAge (int newAge)
    {
        age = newAge;
    }
    public void setName (String newName)
    {
        Name = newName;
    }
    public void setRoll (int newId)
    {
        Id = newId;
    }
    public static void main (String[]args)
    {
        Encapsulation obj = new Encapsulation ();
        obj.setName ("Dhaush");
        obj.setAge (19);
        obj.setRoll (15);
        Encapsulation obj2 = new Encapsulation ();
        obj2.setName ("bharath");
        obj2.setAge (19);
        obj2.setRoll (8);
        Encapsulation obj3 = new Encapsulation ();
        obj3.setName ("gokul");
        obj3.setAge (19);
        obj3.setRoll (19);
        Encapsulation obj4 = new Encapsulation ();
        obj4.setName ("gobi");
        obj4.setAge (19);
        obj4.setRoll (18);
        Encapsulation obj5 = new Encapsulation ();
        obj5.setName ("praveer");
        obj5.setAge (19);
        obj5.setRoll (23);
        System.out.println ("The Name is : " + obj.getName ());
        System.out.println ("The Age is : " + obj.getAge ());
        System.out.println ("The Id is : " + obj.getRoll ());
        
        System.out.println ("The Name is : " + obj2.getName ());
        System.out.println ("The Age is : " + obj2.getAge ());
        System.out.println ("The Id is : " + obj2.getRoll ());
        
        System.out.println ("The Name is : " + obj3.getName ());
        System.out.println ("The Age is : " + obj3.getAge ());
        System.out.println ("The Id is : " + obj3.getRoll ());
        
        System.out.println ("The Name is : " + obj4.getName ());
        System.out.println ("The Age is : " + obj4.getAge ());
        System.out.println ("The Id is : " + obj4.getRoll ());
        
        System.out.println ("The Name is : " + obj5.getName ());
        System.out.println ("The Age is : " + obj5.getAge ());
        System.out.println ("The Id is : " + obj5.getRoll ());
    }
}