
                 //Runnable interface//


public class RunnableInterface extends Thread{
	public void run() {
		for(int i = 0;i<=5;i++) {
			try {
				Thread.sleep(200);
			}
			catch(Exception val) {
				System.out.println(val);
			}
			System.out.println("The Runnable interface is : " +i);
		}
	}
	public static void main(String args[]) {
		RunnableInterface val1 = new RunnableInterface();
		RunnableInterface val2 = new RunnableInterface();
		RunnableInterface val3 = new RunnableInterface();
		val1.start();
		try {
			val1.join();
		}
		catch(Exception val) {
			System.out.println(val);
		}
		val2.start();
		val3.start();
		
	}
}