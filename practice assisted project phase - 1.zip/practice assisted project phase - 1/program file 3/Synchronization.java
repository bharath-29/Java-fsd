class local
{
  public void display(String msg)
  {
    System.out.print ("Hai " +msg);
    try
    {
      Thread.sleep(1000);
    }
    catch(InterruptedException etr)
    {
      etr.printStackTrace();
    }
    System.out.println ("helo");
  }
}

class mav extends Thread
{
  String msg;
  local dobj;
  mav (local fp,String str)
  {
    dobj = fp;
    msg = str;
    start();
  }
  public void run()
  {
    dobj.display(msg);
  }
}

public class Synchronization
{
  public static void main (String[] args)
  {
    local don = new local();
    mav ss = new mav(don, "welcome ");
    mav ss1= new mav(don," programmer ");
    mav ss2 = new mav(don, " bharath ");
  }
}