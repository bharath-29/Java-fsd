import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
public class Filecreate{
	public static void main(String[] args) throws IOException {
		File fi = new File("The new file crating ");
		try {
			if(fi.createNewFile()) {
				System.out.println("File created");
			}else {
				System.out.println("File alredy exist");
			}
		}catch(IOException bh) {
			System.out.println(bh.getMessage());
		}
		 FileWriter fr = new FileWriter("C:\\Users\\admin\\Desktop\\jj\\india.txt",true);
		 PrintWriter wr = new PrintWriter(fr);
		 System.out.println("South");
		 System.out.close();
	
}
}