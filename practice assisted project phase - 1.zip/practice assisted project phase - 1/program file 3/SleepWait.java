class SleepWait
{
    private static SleepWait LOCK = new SleepWait();
    public static void main(String args[]) 
    		throws InterruptedException
    {
        Thread.sleep(3000);
        Thread.currentThread().getName();
        System.out.println("Its tack some time please wait.....");
        synchronized (LOCK) 
        {
            LOCK.wait(3000);
            System.out.println("hi welcome bzck...");
        }
    }
}
