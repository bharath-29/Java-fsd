public class ThrowandKey
    {
        public static void Division()
        		throws ArithmeticException
        {
            int bh=50,br=5,ab; ab = bh / br;
            System.out.print("\n The final result is : " + ab);
        }
         public static void main(String[] args)
        {
ThrowandKey value = new ThrowandKey();
             try
            {
                value.Division();
            }
            catch(ArithmeticException merg)
            {
                System.out.print("\n"+merg.getMessage());
            }
            System.out.print("\n finish");
        }
    }
