import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

class Filedelete{
	public static void main(String[] args) {
		Path fir = Paths.get("C:\\Users\\admin\\Desktop\\jj\\india.txt");
		try {
			Files.delete(fir);
			System.out.println("File deleted");
		}
		catch(Exception rr) {
			System.out.println("failed");
		}
	}
}