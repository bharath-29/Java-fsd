import java.util.Scanner;

public class ExceptionHandling {

    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.println("Please enter a number");
        int val = scr.nextInt();

        int arr[] = new int[10];

        try {
            arr[val] = 10 * val;
            System.out.println(arr[val]);
        } catch (ArithmeticException emt) {
            System.out.println("Please enter non-zero input");
        } catch (ArrayIndexOutOfBoundsException emt) {
            System.out.println("Please enter the correct array index");
        }
    }
}