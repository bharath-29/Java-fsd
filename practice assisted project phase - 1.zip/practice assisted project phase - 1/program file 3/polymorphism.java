class car{
	public void vall() {
		System.out.println("The car colour : ");
	}
}
class bmw extends car {
	public void vall() {
		System.out.println("The BMW looking black and going smoooth");
	}
}
public class polymorphism{
	public static void main(String [] args) {
		car Car1 = new car();
		car bmw1 = new bmw();
		Car1.vall();
		bmw1.vall();
	}
}