import java.util.*;

public class queue {
	
public static void main(String[] args) {

        		Queue<Integer> developer = new LinkedList<>();
        		developer.add(20);
        		developer.add(30);
        		developer.add(99);
        		developer.add(10);
        		developer.add(3);
System.out.println("Queue is : " + developer);
        		System.out.println(" romove value of queue is : " + developer.peek());
        		developer.remove();
        		System.out.println("final poped queue is  : " + developer);
        		
    	}
}
