public class doublyLinkedList { 
    static Node top; 
    static class Node { 
        int imp; 
        Node val1, val2; 
        Node(int d) 
        { 
            imp = d; 
            val1 = val2 = null; 
        } 
    } 
    void reverse() 
    { 
        Node temp = null; 
        Node current = top; 
        while (current != null) { 
            temp = current.val2; 
            current.val2 = current.val1; 
            current.val1 = temp; 
            current = current.val2; 
        } 
        if (temp != null) { 
            top = temp.val2; 
        } 
    } 
    void push(int new_data) 
    { 
        Node new_node = new Node(new_data); 
        new_node.val2 = null; 
        new_node.val1 = top; 
        if (top != null) { 
            top.val2 = new_node; 
        } 
        top = new_node; 
    } 
    void printList(Node node) 
    { 
        while (node != null) { 
            System.out.print(node.imp + " "); 
            node = node.val1; 
        } 
    } 
    public static void main(String[] args) 

    { 
        doublyLinkedList list = new doublyLinkedList(); 

        list.push(2); 

        list.push(4); 

        list.push(8); 

        list.push(10); 

        System.out.println("The current linked list "); 

        list.printList(top); 
        list.reverse(); 

        System.out.println(""); 

        System.out.println("Doubly Linked List is "); 

        list.printList(top); 

    } 
}