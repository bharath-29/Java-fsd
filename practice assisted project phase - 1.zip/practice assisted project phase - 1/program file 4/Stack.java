import java.util.List;
import java.util.ArrayList;

public class Stack {
    public static void main(String[] args) {
        StackPushPopExample vvd = new StackPushPopExample(5);
        vvd.push(10);
        vvd.push(2);
        vvd.push(6);
        vvd.push(78);
        vvd.push(13);
        vvd.pop();
        System.out.println("values of the stack: " + vvd.peek());
        System.out.println("Stack : ");
        
        for (Integer allItem : vvd.getAllItems()) {
            System.out.println(allItem);
        }

        vvd.pop();
        System.out.println("Remaining stack items:");
        
        for (Integer allItem : vvd.getAllItems()) {
            System.out.println(allItem);
        }
    }
}

class StackPushPopExample {
    private final List<Integer> intStack;

    public StackPushPopExample(int stackSize) {
        intStack = new ArrayList<>(stackSize);
    }

    public void push(int item) {
        intStack.add(0, item);
    }

    public int pop() {
        if (!intStack.isEmpty()) {
            int item = intStack.get(0);
            intStack.remove(0);
            return item;
        } else {
            return -1;
        }
    }

    public int peek() {
        if (!intStack.isEmpty()) {
            return intStack.get(0);
        } else {
            return -1;
        }
    }

    public List<Integer> getAllItems() {
        return intStack;
        //System.out.println("The poped value is : " + );
    }
}