class Arrayqueries
{ 
    static int a = 10;
    static int b = 30; 
    static long deep[][] = new long[b][a + 1]; 
    static void dddm(int arr[], int nom) 
    { 
        for (int v = 0; v < nom; v++) 
            deep[v][0] = arr[v]; 
        for (int j = 1; j <= a; j++) 
            for (int i = 0; i <= nom - (1 << j); i++) 
                deep[i][j] = deep[i][j - 1] + deep[i + (1 << (j - 1))][j - 1]; 
    } 
    static long fire(int L, int R) 
    {
        long val = 0; 
        for (int j = a; j >= 0; j--)  
        { 
            if (L + (1 << j) - 1 <= R)  
            { 
                val = val + deep[L][j];
                L += 1 << j; 
            } 
        } 
        return val; 
    }
    public static void main(String args[]) 
    { 
        int arr[] = { 2,5,6,9,1,4 }; 
        int n = arr.length; 
        dddm(arr, n); 
        System.out.println(fire(1,5)); 
        System.out.println(fire(3,6)); 
        System.out.println(fire(9,10)); 
    } 
}
