import java.util.LinkedList;
import java.util.Queue;

import java.util.*;

public class LinkedLists {
	
public static void main(String[] args) {

        		List<String> developer = new LinkedList<>();
        		developer.add("Bharath");
        		developer.add("Gokul");
        		developer.add("Dhanush");
        		developer.add("Max");
        		developer.add("Mark John");
        		System.out.println("The Linkedlist String size is : " +developer.size());
System.out.println("LinkedList  is : " + developer);
        		   	}
}