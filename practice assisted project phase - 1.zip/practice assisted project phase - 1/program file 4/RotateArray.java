import java.util.Arrays;
public class RotateArray {
		public static void lc(int[] x) {
			int fin = x[x.length -1];
			for(int i = x.length -2 ; i>=0;i--) {
				x[i+1] = x[i];
			}
			x[0] = fin;
			
		}
		public static void vrc(int[] x, int a) {
			if(a < 0 || a>= x.length) {
				return;
			}
			for(int i =0 ; i<a;i++) {
				lc(x);
			}
		}
	public static void main(String[] args) {
		int[] x = {1,3,9,7,2,4};
		int a = 3;
		vrc(x,a);
		System.out.println(Arrays.toString(x));
		

	}

}
