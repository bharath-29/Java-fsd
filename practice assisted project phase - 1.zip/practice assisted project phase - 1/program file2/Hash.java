import java.util.HashSet;
public class Hash {

			public static void main(String[] args) {
		    HashSet<String> bharath = new HashSet<String>();
		    bharath.add("Bharath");
		    bharath.add("Rajan");
		    bharath.add("Deepan");
		    for(String val : bharath) {
		    	System.out.println(val);
		    }
			}

		}


	


