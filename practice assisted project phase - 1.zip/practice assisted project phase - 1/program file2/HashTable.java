import java.util.Hashtable;

public class HashTable {

	public static void main(String[] args) {
		Hashtable<Integer,String> ddv = new Hashtable<Integer,String>();
		ddv.put(1813008, "Bharath");
		ddv.put(1813015, "Dhanush");
		ddv.put(1813019, "Gokul");
		System.out.println(ddv);
		
	}

}
