
                              // method call //

public class method {
	public static void main(String[] args) {
		String first_name = "Bharath";
		String last_name = "Ravindran";
		System.out.println(first_name + last_name);
	}
	public String name(String first_name,String last_name) {
		return first_name + last_name;
		
	}
}
