class Anonymous{
	   public void display() {
	}
	}
	public class inner {
	public static void main(String[] args) {
	Anonymous all = new Anonymous() {

	         public void display() {
	            System.out.println("The values Anonymous class");
	         }
	};
	      
	      all.display();
	   }
	}
