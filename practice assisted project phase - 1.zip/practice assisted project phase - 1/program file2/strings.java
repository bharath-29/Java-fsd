
public class strings {

	public static void main(String[] args) {
  
		
		// string comparition
		String name1 = "Bharath";
		String name2 = "Java";
		System.out.println(name1==name2);
		
		//uper to lowercase  //
		
		String name3 = "WELCOME TO THE NEW LIFE";
		String name4 = (name3.toLowerCase());
		System.out.println(name4);
		
		// low to upp//
		
		String name5 = "learning";
		String name6 = (name5.toUpperCase());
		System.out.println(name6);
		
		// add two string //
		 String a = "tack";
		 String b = "care";
		 System.out.println(a+ " " +b);
		 
		 // find length // 
		 String ell = "Iam eating apple";
		 System.out.println(ell.length());


		 //sub string//
		 String sub = "Hello How Are you";
		 System.out.println(sub.substring(3));
		 
		 // replace//
		    String val="Hai Bharath";
			String replace=val.replace('a', 'i');
			System.out.println(replace);

			
			//String builders insert //
			
			StringBuilder vas = new StringBuilder("Live ");
			vas.append("Long Life");
			System.out.println(vas);
			
			//find index //
			
			StringBuilder ddd = new StringBuilder("Bharath");
			int valuee = ddd.indexOf("h");
			System.out.println(valuee);
			
			// remove //
			
			StringBuilder stringBuilder = new StringBuilder("English");
			stringBuilder.deleteCharAt(2);
			System.out.println(stringBuilder);
			
			
			
			
			
			
	}

}
