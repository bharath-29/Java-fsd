import java.util.*;
public class linkedList {

	public static void main(String[] args) {
		LinkedList<String> value = new LinkedList<String>();
		LinkedList linkedList = new LinkedList();
		linkedList.add("b");
		linkedList.add("h");
		linkedList.add("a");
		
		LinkedList linkedList2 = new LinkedList();
		//linkedList2.add("h");
		System.out.println(linkedList);
		System.out.println(linkedList.size());
		
		
		
	}

}
