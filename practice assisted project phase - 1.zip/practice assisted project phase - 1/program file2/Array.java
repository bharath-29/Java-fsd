
// single array

public class Array {
public static void main(String[] args) {
	int[] bh = new int[10];
	int a = 8;
	for(int a1 : bh) {
		System.out.println(a);
		
	}
	
	// multi array
	int multi[][] = {{18,19,20},{1,3,5},{4,2,9}};
	for(int i =0;i<3;i++) {
		for(int j=0;j<3;j++) {
			System.out.println(multi[i][j] + " ");
			System.out.println("The length" +multi.length);
		}
	}
}}

