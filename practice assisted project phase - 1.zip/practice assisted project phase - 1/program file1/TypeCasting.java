
public class TypeCasting {

	public static void main(String[] args) {
		// Explicit //
		
		double a = 75.0d;
		System.out.println("double value is : " +a);
		float b = (float)a;
		System.out.println("float value is : " +b);
		long c = (long)b;
		System.out.println("long value is : " +c);
		int d = (int)c;
		System.out.println("int value is : " +d);
		short e = (short)d;
		System.out.println("Short value is :" +e);
		byte f = (byte)e;
		System.out.println("byte value is : " +f);
		
		
		// implicit //
		
		
		byte val1 = 29;
		System.out.println("The byte value is : " +val1);
		short val2 = val1;
		System.out.println("The byte to short is : " +val2);
		int val3 = val2;
		System.out.println("The short to int is : " +val3);
		long val4 = val3;
		System.out.println("The int to long is :" +val4);
		float val5 = val4;
		System.out.println("The long to float is :" +val5);
		double val6 = val5;
		System.out.println("The float to double is :" +val6);
		

	}

}
