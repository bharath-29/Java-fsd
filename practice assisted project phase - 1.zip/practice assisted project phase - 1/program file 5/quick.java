import java.util.Arrays;

public class quick {
 
    public static void main(String[] args) {
        int[] array = {2, 4, 1, 6, 3, 10};
        quickSort(array, 0, array.length-1);
        System.out.println(Arrays.toString(array));
    }
    public static void quickSort(int[] arr, int first, int last){
        int part = partition(arr, first, last);
        if(part-1>first) {
            quickSort(arr, first, part - 1);
        }
        if(part+1<last) {
            quickSort(arr, part + 1, last);
        }
    }
    public static int partition(int[] arr, int start, int end){
        int p = arr[end];
        for(int i=start; i<end; i++){
            if(arr[i]<p){
                int temp= arr[start];
                arr[start]=arr[i];
                arr[i]=temp;
                start++;
            }
        }
        int temp = arr[start];
        arr[start] = p;
        arr[end] = temp;
        return start;
    }
}