import java.util.Arrays;

public class Exponential {
public static  void main(String[] args){
    int[] array = {19,12,300,40};
    
    int[] a = array;
    int length= array.length;
    int value = 12;
    int th = exponential(array,length,value);

    if(th<0){
       System.out.println( " Not in the array List");
    }else {

        System.out.println( "The array index is :"+th);
    }
        }
public static int exponential(int[] arrval ,int length, int value ){

if(arrval[0]==value){
    return 0;
    }
int bh=1;
while(bh<length && arrval[bh]<=value){

    bh=bh*2;
}
return Arrays.binarySearch(arrval,bh/2,Math.min(bh,length),value);
}


}
