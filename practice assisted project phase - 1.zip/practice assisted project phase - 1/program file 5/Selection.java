
public class Selection {
public static void def(int a[],int val1,int val2) {
	int temp =a [val1];
	a[val1] = a[val2];
	a[val2]= temp;
	
}
public static void mm(int a[],int n) {
	for(int i =0;i<n-1;i++) {
		int min=i;
		for(int j=i+1;j<n;j++) {
			if(a[j]<a[min])
				min =j;
		}
		def(a,i,min);
	}
}
	public static void main(String[] args) {
		int a[]= {1,5,100,99,12,19,20};
		mm(a,a.length);
		System.out.println("The Sorting value is : ");
		for(int i = 0;i<a.length;i++)
			System.out.println(a[i]+"");
		System.out.println();
	}

}
