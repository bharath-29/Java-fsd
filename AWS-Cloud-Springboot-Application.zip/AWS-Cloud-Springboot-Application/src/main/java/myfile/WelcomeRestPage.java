package myfile;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WelcomeRestPage {
	@GetMapping("/")
	public String hello() {
		return "Hai iam Bharath This Project Name is Deploye the Webapplication in Spring-boot, its working fine...."; 
		
	}

}
