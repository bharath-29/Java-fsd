package myfile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringUserauth2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
