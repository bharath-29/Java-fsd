import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
public class CircularLinkedList{

	public static void main(String[]args) {
		LinkedList<Integer> list = new LinkedList<Integer>();
	    list.add(12);
	    list.add(1);
	    list.add(23);
	    list.add(100);
	    list.add(12);
	    System.out.println("The Before Sorted values are : "+list);
	    Collections.sort(list);
	    System.out.println("The Sorted value is : "+list);
	    Collections.sort(list,Collections.reverseOrder());
	    System.out.println(list);
	}
}
