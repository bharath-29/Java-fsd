import java.util.Arrays;
public class smallestArray {
	public static int small(Integer[]array,float v) {
		Arrays.sort(array);
		return array[(int) (v-1)];	
	}
	public static void main(String[] args) {
	Integer array[] = new Integer[] {1,3,7,4,6,9,100};
	int v = 4;
	System.out.println("Kth Smallest value is : " + small(array,v));
	
	}

}
