public class MultiplyTwoArrays {

	public static void main(String[] args) {
		int[][] a = {{9,4,6}, {3,4,5},{4,6,7}};
		int[][] b = {{3,4,9}, {5,5,5},{10,20,30}};
		
		int[][] xyz = new int[3][3];
		int val1, val2;
		
		for(val1 = 0; val1 < a.length; val1++)
		{
			for(val2 = 0; val2 < a[0].length; val2++)
			{
				xyz[val1][val2] = a[val1][val2]*b[val1][val2];
			}
		}
		System.out.println("Multiply two array is : ");
		
		for(val1 = 0; val1 < a.length; val1++)
		{
			for(val2 = 0; val2 < a[0].length; val2++)
			{
				System.out.format("%d\t",xyz[val1] [val2]);
			}
			System.out.println(" ");
		}
	}
}
