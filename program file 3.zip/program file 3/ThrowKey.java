import java.io.IOException;
public class ThrowKey {
	static void display()
	throws ArithmeticException{
		int result = 20/2;
		System.out.println("Results : " +result);
	}

	public static void main(String[] args) {
		try {
			display();
		}
		catch( ArithmeticException r) {
			System.out.println(" The Exception : " +r.getMessage());
		}
		System.out.println(" No Exception");

	}


		
	}

	





