abstract class mon{

   public void syn(){
     System.out.println("The Abstract done");
   }

   abstract public void dark();
}

public class Abstract extends mon{

   public void dark()
   {
       System.out.println("Successfully done....");
   }
   public static void main(String args[]){
       Abstract obj = new Abstract();
       obj.dark();
       obj.syn();
   }
}