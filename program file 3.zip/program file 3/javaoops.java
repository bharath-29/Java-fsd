
public class javaoops {
	String clg , branch;
	int num;
	public javaoops (String dhanush,String bharath , int num) {
		this.clg = dhanush;
		this.branch = bharath;
		this.num = num;
		
		
	}
	public static void main(String[] args) {
		javaoops dhanush = new javaoops("Ksr college ","CSE, ", 1813015);
		javaoops bharath = new javaoops("Ksr college ","CSE, ", 1813008);
		javaoops gokul = new javaoops("Ksr college ","CSE, ", 1813019);
		System.out.println("They are " + dhanush.clg+""+dhanush.branch+"Roll num is : "+dhanush.num);
		System.out.println("They are " + bharath.clg+""+bharath.branch+"Roll num is : "+bharath.num);
		System.out.println("They are " + gokul.clg+""+gokul.branch+"Roll num is : "+gokul.num);
		

	}

}


                         