
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
public class Writefile{
	public static void main(String[] args) {
		Path fir = Paths.get("C:\\Users\\admin\\Desktop\\jj\\normal.txt");
		try {
			Files.isWritable(fir);
			System.out.println("sucessfully added");
		}
		catch(Exception rr) {
			System.out.println("Error");
		}
	}
}