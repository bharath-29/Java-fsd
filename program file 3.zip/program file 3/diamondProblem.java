interface mainclass{
	
    default void deep() 
    { 
        System.out.println("Execution successfull"); 
    } 
} 
interface mainclass2
{  
    default void deep() 
    { 
        System.out.println("The entier process compled done "); 
    } 
}  
public class diamondProblem implements mainclass, mainclass2
{  
    public void show() 
    {  
        mainclass.super.deep(); 
        mainclass2.super.deep(); 
    } 
	public void deep() {
		mainclass.super.deep();
	}
	public static void main(String args[]) 
    { 
    	diamondProblem ob = new diamondProblem(); 
        ob.show(); 
    } 
}
