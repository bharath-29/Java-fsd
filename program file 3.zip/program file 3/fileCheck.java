
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
public class fileCheck{
	public static void main(String[] args) {
		Path fir = Paths.get("C:\\Users\\admin\\Desktop\\jj\\india.txt");
		try {
			Files.getFileStore(fir);
			System.out.println("Sucessfully added");
		}
		catch(Exception rr) {
			System.out.println("Error not in the list");
		}
	}
}