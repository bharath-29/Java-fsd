public class finalKey {
	public static void main(String[] args) {
		int val1, val2 , val3 = 0;
		try {
			val1 = 0;
			val2 = 18;
			val3 = val2/val1;
			System.out.println(val3);
			System.out.println("Thread end ");
		}
		catch(ArithmeticException e) {
			System.out.println("This is invalid divisible" +e.getMessage());
			
		}
		finally{
			System.out.println("The finally " +val3);
		}
	}

}
