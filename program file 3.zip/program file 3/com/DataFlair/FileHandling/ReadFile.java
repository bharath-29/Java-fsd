package com.DataFlair.FileHandling;
import java.io.FileReader;
import java.io.IOException;
public class ReadFile{
	public static void main(String[] args) throws IOException {
		FileReader f = new FileReader("C:\\Users\\admin\\Desktop\\jj\\normal.txt");
		int i;
		while((i=f.read())!=-1)
			System.out.println((char)i);
		f.close();
	}
}
