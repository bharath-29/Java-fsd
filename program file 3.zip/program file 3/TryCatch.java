public class TryCatch {
	public static void main(String[] args) {
		int val1, val2 , val3;
		try {
			val1 = 0;
			val2 = 18;
			val3 = val2/val1;
			System.out.println(val3);
			System.out.println("Hai end of Thread");
		}
		catch(ArithmeticException e) {
			System.out.println("This is invalid divisible");
			
		}
		catch(Exception v) {
			System.out.println("Exception occurs");
		}
		System.out.println("null values");
	}

}
