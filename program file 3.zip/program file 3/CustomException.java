class TheException extends Exception 
{ 
    public TheException(String value) 
    { 
        super(value); 
    } 
} 
public class CustomException 
{ 
    void check(int val) throws TheException{
    	if(val<1000) {
    		throw new TheException("The value is invalid");
    	}
    }
    public static void main(String[] args) {
    	CustomException  obj= new CustomException ();
    	try {
    		obj.check(300);
    	}
    	catch(TheException vee) {
    		System.out.println("The exception done");
    		System.out.println(vee.getMessage());
    	}
    }
}