

class main{
	public void met() {
		System.out.println("This is common inheritance ");
	}
}
class dev extends main{
	public void met2() {
		System.out.println("Inheritance program");
	}
	
}
public class inheritance {
	public static void main(String[] args) {
		dev d = new dev();
		d.met();
		d.met2();
	}

}
