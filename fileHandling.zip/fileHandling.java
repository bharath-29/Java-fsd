
        //Java FileHandling//

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
public class fileHandling {
	public static void main(String[] args) {
		File myfile = new File("C:\\Users\\admin\\Desktop\\information.txt");
		try {
		if(myfile.createNewFile()) {
			System.out.println("File Created Sucessfully...");
		}
		else {
			System.out.println("File already created, Please check your Desktop...");
		}

	}catch(IOException ve) {
		System.out.println("File Error..");
	}
		try {
			FileWriter doc = new FileWriter("C:\\Users\\admin\\Desktop\\information.txt");
			doc.write("Hai iam bharath very happy to learn java ");
			doc.close();
			System.out.println("Datas stored sucessfully....");
		} catch (IOException emp) {
			System.out.println("File error");
			emp.printStackTrace();
		}
		char[] data = new char[200];
		try {
			FileReader val = new FileReader("C:\\\\Users\\\\admin\\\\Desktop\\\\information.txt");
			val.read(data);
			System.out.println("Information Sucessfully get from the file....");
			System.out.print("The File Information is : ");
			System.out.println(data);
			val.close();
		}catch(IOException nr) {
			System.out.println("Please check its error");
		}
		String dop = "The new information is added by using append ";
		try {
			FileWriter cool = new FileWriter("C:\\\\\\\\Users\\\\\\\\admin\\\\\\\\Desktop\\\\\\\\information.txt",true);
			cool.write(dop);
			System.out.println("The appended sucessfully completed......");
			cool.close();
		}catch(IOException bhr){
			System.out.println("File Error.. please check ");
			
		}
	}
}
